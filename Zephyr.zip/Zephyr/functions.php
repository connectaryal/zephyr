<?php
// Make theme available for translation
// Translations can be filed in the /languages/ directory
load_theme_textdomain( 'your-theme', TEMPLATEPATH . '/languages' );
 
$locale = get_locale();
$locale_file = TEMPLATEPATH . "/languages/$locale.php";
if ( is_readable($locale_file) )
    require_once($locale_file);
 
// Get the page number
function get_page_number() {
    if ( get_query_var('paged') ) {
        print ' | ' . __( 'Page ' , 'your-theme') . get_query_var('paged');
    }
}
 // end get_page_number


function new_theme_setup() {

/* Activate feature image  */ 

add_theme_support('post-thumbnails');

/* Activate Background image  */ 

add_theme_support('custom-background');

/* Activate custom header  */ 

add_theme_support('custom-header');

add_theme_support('post-formats',array('aside','image','video'));
/*
==========================================
 Activate menus
==========================================
*/

	add_theme_support('menus');
	
	register_nav_menu('primary', 'Primary Header Navigation');
	register_nav_menu('secondary', 'Footer Navigation');
	register_nav_menu('header', 'Header Navigation');
	
}

add_action('init', 'new_theme_setup');

function set_excerpt_length(){
	return 40;
}
add_filter('excerpt_length','set_excerpt_length');

/*
	==========================================
	 Sidebar function
	==========================================
*/
function awesome_widget_setup() {
	
	register_sidebar(
			array(	
			'name'	=> 'Sidebar',
			'id'	=> 'sidebar-1',
			'class'	=> 'custom',
			'description' => 'Standard Sidebar',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h1 class="widget-title">',
			'after_title'   => '</h1>',
		)
	);
	
	register_sidebar(
			array(	
			'name'	=> 'Tags',
			'id'	=> 'sidebar-tags',
			'class'	=> 'custom',
			'description' => 'Standard Sidebar 2',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h1 class="widget-title">',
			'after_title'   => '</h1>',
		)
	);
	register_sidebar(
			array(	
			'name'	=> 'Recent-Post',
			'id'	=> 'sidebar-recentpost',
			'class'	=> 'custom',
			'description' => 'Standard Sidebar 2',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h1 class="widget-title">',
			'after_title'   => '</h1>',
		)
	);
	register_sidebar(
			array(	
			'name'	=> 'ads',
			'id'	=> 'ads',
			'class'	=> 'custom',
			'description' => 'Standard widget for ads',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h1 class="widget-title">',
			'after_title'   => '</h1>',
		)
	);
	register_sidebar(
			array(	
			'name'	=> 'Footer Widget1',
			'id'	=> 'footer-widget1',
			'class'	=> 'custom',
			'description' => 'Standard widget for footer1',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h1 class="widget-title">',
			'after_title'   => '</h1>',
		)
	);
		register_sidebar(
			array(	
			'name'	=> 'Footer Widget2',
			'id'	=> 'footer-widget2',
			'class'	=> 'custom',
			'description' => 'Standard widget for footer2',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h1 class="widget-title">',
			'after_title'   => '</h1>',
		)
	);
			register_sidebar(
			array(	
			'name'	=> 'Footer Widget3',
			'id'	=> 'footer-widget3',
			'class'	=> 'custom',
			'description' => 'Standard widget for footer3',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h1 class="widget-title">',
			'after_title'   => '</h1>',
		)
	);
			register_sidebar(
			array(	
			'name'	=> 'aboutme',
			'id'	=> 'aboutme',
			'class'	=> 'custom',
			'description' => 'Standard widget for aboutme',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h1 class="widget-title">',
			'after_title'   => '</h1>',
		)
	);
			register_sidebar(
			array(	
			'name'	=> 'search',
			'id'	=> 'sidebar-search',
			'class'	=> 'custom',
			'description' => 'Standard widget for aboutme',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h1 class="widget-title">',
			'after_title'   => '</h1>',
		)
	);
}
add_action('widgets_init','awesome_widget_setup');
?>