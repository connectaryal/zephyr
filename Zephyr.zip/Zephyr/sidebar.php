<div id="secondary" class="widget-area" role="complementary">
						<aside  class="widget widget_search">
							<form role="search" method="get" class="search-form" action="">
								<label> <span class="screen-reader-text">Search for:</span>
									<input type="search" class="search-field" placeholder="Search here...." value="" name="s" title="Search for:">
								</label>
								<input type="submit" class="search-submit" value="Search">
							</form>
						</aside>
						<aside  class="widget widget_featured_post">
						<?php dynamic_sidebar('aboutme'); ?>
							
							
						</aside>
						<aside  class="widget widget_social_networks">
							<h3 class="widget-title">FOLLOW US</h3>
							<ul>
								<li><a href="#" class="facebook-icon"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#" class="twitter-icon"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#" class="pinterest-icon"><i class="fa fa-pinterest-p"></i></a></li>
								<li><a href="#" class="instagram-icon"><i class="fa fa-instagram"></i></a></li>
								<li><a href="#" class="rss-icon"><i class="fa fa-rss"></i></a></li>
								<li><a href="#" class="dribbble-icon"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#" class="linkedin-icon"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#" class="google-plus-icon"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</aside>
						<div class="advertisement">
							<?php dynamic_sidebar('ads'); ?>
						</div>
						<aside  class="widget widget_subscribe">
							<h3 class="widget-title">Newsletter</h3>
							<?php dynamic_sidebar('sidebar-search'); ?>
							
						</aside>
						<aside  class="widget widget_recent_entries">
						<?php dynamic_sidebar('sidebar-recentpost'); ?>	
						</aside>
						<aside  class="widget widget_categories">
							<?php dynamic_sidebar('sidebar-1'); ?>
						</aside>
						<aside  class="widget widget_tag_cloud">
							<div class="tagcloud">
							<?php dynamic_sidebar('sidebar-tags'); ?>
							</div>
						</aside>
					</div>
				</div>
			</div>
		</div>
