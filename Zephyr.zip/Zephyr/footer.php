<footer id="colophon" class="site-footer" role="contentinfo">
			<div class="widget-area">
				<div class="container">
					<div class="row">
						<div class="column">
							<aside  class="widget widget_recent_entries">
								<h5 class="widget-title">MOST POPULAR</h5>
								<?php
								$lastBlog = new WP_Query('type=post&posts_per_page=3&category_name=POPULAR');
			
		if( $lastBlog->have_posts() ):
			
			while( $lastBlog->have_posts() ): $lastBlog->the_post(); ?>
				
								<article class="post">
									<a href="#" class="post-thumbnail"><?php the_post_thumbnail(); ?></a>
									<header class="entry-header">
										<h3 class="entry-title"><a href="#"><?php the_title(); ?></a></h3>
										<div class="entry-meta">
											<span><a href="#"><?php the_date(); ?></a></span>
										</div>
									</header>
								</article>
							</aside>
						</div>

					<?php endwhile;
			
		endif;
		
		wp_reset_postdata();
				
		?>
						<div class="column">
							<aside  class="widget widget_photo_gallery">
								<h5 class="widget-title">FLICKR</h5>
								<ul>
								<li><a href="#"> <img src="<?php echo get_stylesheet_directory_uri(). '/images/footer-photo-gallery-img1.jpg' ?>" alt="">
								<li><a href="#"> <img src="<?php echo get_stylesheet_directory_uri(). '/images/footer-photo-gallery-img2.jpg' ?>" alt="">
								<li><a href="#"> <img src="<?php echo get_stylesheet_directory_uri(). '/images/footer-photo-gallery-img3.jpg' ?>" alt="">
								<li><a href="#"> <img src="<?php echo get_stylesheet_directory_uri(). '/images/footer-photo-gallery-img4.jpg' ?>" alt="">
								<li><a href="#"> <img src="<?php echo get_stylesheet_directory_uri(). '/images/footer-photo-gallery-img5.jpg' ?>" alt="">
								<li><a href="#"> <img src="<?php echo get_stylesheet_directory_uri(). '/images/footer-photo-gallery-img6.jpg' ?>" alt="">
								</ul>
							</aside>
						</div>
						<div class="column">
							<aside  class="widget widget_contact">
								<h5 class="widget-title">contact us</h5>
								<?php dynamic_sidebar('footer-widget3'); ?>
							</aside>
						</div>
					</div>
				</div>
			</div>
			<div class="site-info">
				<div class="container">
					<p>
						Copyright © 2015 <a href="#">Blog Design</a>. All rights reserved.
					</p>
				</div>
			</div>
		</footer>
		<script src="js/jquery.js"></script>
		<script src="js/jquery.flexslider.js"></script>
		<script src="js/jquery.aw-showcase.js"></script>
		<script src="js/jquery.meanmenu.js"></script>
		<script>
			$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide",
    controlNav: "thumbnails"
  });
});

		$(document).ready(function(){
			$(".example").css("display", "none");
			$("#search-btn").click(function(){
			$(".example").slideToggle("slow");
			});
		 });

		jQuery(document).ready(function () {
	    jQuery('.header-bottom  .main-navigation').meanmenu({
	    	meanScreenWidth: 991,
	    	meanRevealPosition: "right"
	    });
	});


		$(document).ready(function()
{
	$("#showcase").awShowcase(
	{
		content_width:			700,
		// content_height:			470,
		fit_to_parent:			false,
		auto:					false,
		interval:				3000,
		continuous:				false,
		loading:				true,
		tooltip_width:			200,
		tooltip_icon_width:		32,
		tooltip_icon_height:	32,
		tooltip_offsetx:		18,
		tooltip_offsety:		0,
		arrows:					true,
		buttons:				true,
		btn_numbers:			true,
		keybord_keys:			true,
		mousetrace:				false, /* Trace x and y coordinates for the mouse */
		pauseonover:			true,
		stoponclick:			true,
		transition:				'hslide', /* hslide/vslide/fade */
		transition_delay:		300,
		transition_speed:		500,
		show_caption:			'onhover', /* onload/onhover/show */
		thumbnails:				true,
		thumbnails_position:	'outside-last', /* outside-last/outside-first/inside-last/inside-first */
		thumbnails_direction:	'horizontal', /* vertical/horizontal */
		thumbnails_slidex:		0, /* 0 = auto / 1 = slide one thumbnail / 2 = slide two thumbnails / etc. */
		dynamic_height:			true, /* For dynamic height to work in webkit you need to set the width and height of images in the source. Usually works to only set the dimension of the first slide in the showcase. */
		speed_change:			false, /* Set to true to prevent users from swithing more then one slide at once. */
		viewline:				false /* If set to true content_width, thumbnails, transition and dynamic_height will be disabled. As for dynamic height you need to set the width and height of images in the source. */
	});
});
		</script>

		
</body>
</html>
<?php wp_footer() ?>