<?php get_header(); ?>

		<div id="content" class="site-content"> 
			<div class="top-section">
				<div class="container">
				<div class="row">
				<?php 

$lastBlog = new WP_Query('type=post&posts_per_page=3&category_name=Lifestyle');
			
		if( $lastBlog->have_posts() ):
			
			while( $lastBlog->have_posts() ): $lastBlog->the_post(); ?>
				
				
					
						<div class="column">
							<article class="post">
								<div class="image-holder">
									<a href="#" class="post-thumbnail"><?php the_post_thumbnail(); ?></a>
								</div>
								<header class="entry-header">
									<span class="category"><a href="#">Lifestyle</a></span>
									<h2 class="entry-title"><a href="#"><?php the_title(); ?></a></h2>
									<div class="entry-meta">
										<span><a href="#"><?php the_date(); ?></a></span>
									</div>
								</header>
							</article>
						</div>
					
					<?php endwhile;
			
		endif;
		
		wp_reset_postdata();
				
		?>
		</div>
				</div>
			</div> 


			<div class="container">
				<div class="row">
					<div id="primary" class="content-area">
						<main id="main" class="site-main" role="main">
						<?php 
						$lastBlog = new WP_Query('type=post&posts_per_page=4&category_name=Blog');
						if( $lastBlog->have_posts() ):
						while( $lastBlog->have_posts() ): $lastBlog->the_post(); ?>
							<article class="post">
								<a href="#" class="post-thumbnail"><?php the_post_thumbnail(); ?></a>
									<header class="entry-header">
										<span class="category"><a href="#"> <?php the_category(); ?> </a></span>
										<h2 class="entry-title"><a href="<?php the_permalink(); ?> "> <?php the_title(); ?> </a></h2>
										<div class="entry-meta">
											<span><a href="<?php the_permalink(); ?> "><?php the_date(); ?></a></span>
										</div>
									</header>
									<div class="entry-content">
										<p>
											<?php the_excerpt(); ?>
										</p>
									</div>
									<div class="bottom-content">
										<div class="entry-meta">
											<span><a href=" <?php echo get_author_posts_url(get_the_author_meta(ID)); ?> ">By <?php the_author(); ?></a> / <a href="#"> 3 Comments</a></span>
										</div>
										<a href="<?php the_permalink(); ?> " class="read-more">Read More</a>
										<ul class="social-networks">
											<li><a href="#"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
											<li><a href="#"><i class="fa fa-instagram"></i></a></li>
										</ul>
									</div>
							</article>
							<?php endwhile;
							endif;
							wp_reset_postdata();		
								?>
						</main>
						<nav class="navigation pagination" role="navigation">
							<div class="nav-links">							
								<?php next_posts_link('Previous Post') ?></span>
								<?php previous_posts_link('Next Post') ?></a>
							</div>
						</nav>
					</div>
					
<?php get_sidebar(); ?>
<?php get_footer(); ?>